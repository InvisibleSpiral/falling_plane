Hello, welcome to the Spiral Universe Update: Flappy Bird.

    I, InvisibleSpiral, will be posting updates i had made to my code (for school reasons) every time I update it (I am starting like halfway into the project.... BUT ITS OKAY)!

Log( June 03 2025 ):
    Through pain and suffering I had fixed the background and flooring so that they move at a relative pace. ( The floor would NOT position properly and took 11 - 13 tries but we odnt mention that. )

Log( June 04 2025 ):
    Finished re-updating the floor because it has to be a COMPLETE TOOL. Also added plane assets and started working on the plant animation ( Leaving school early for a volunteering event, so this is all. )

Log( June 05 2025 ):
    Added the obsticles, the jumping effect, animation tyoe effects, fixed the time the obsticles take to show up on screen and random size integers.

Log( June 09 2025 ):
    Added collisions, I was very productive,trust!!

Log( June 10 2025 ):
    Added sound effects. It was early release, i did a lot, trust the process. Game is finished!!